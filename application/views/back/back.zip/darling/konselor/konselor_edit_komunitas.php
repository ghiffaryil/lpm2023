<?php $this->load->view('back/template/meta'); ?>
<?php $this->load->view('back/template/header'); ?>
<?php $this->load->view('back/template/sidebar'); ?>

<div class="main-panel">
  <div class="main-content">
    <div class="content-wrapper">
      <!-- Basic Elements start -->
      <section class="basic-elements">
        <div class="row">
          <div class="col-sm-12">
            <div class="content-header"><?php echo $page_title ?></div>
          </div>
        </div>
        <div class="row match-height">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <div class="card-title text-uppercase">Edit Transaksi Komunitas</div>
              </div>
              <div class="card-content">
                <?php if($this->session->flashdata('message')){echo $this->session->flashdata('message');} ?>
                <?php echo validation_errors(); ?>
                <div class="row">
                  <div class="col-md-12">
                    <div class="card-body">
                      <?php echo form_open_multipart($update_action_komunitas) ?>
                      <input type="hidden" name="id_komunitas" value="<?php echo $data->id_komunitas ?>">
                      <input type="hidden" name="id_transaksi_komunitas"
                        value="<?php echo $data->id_transaksi_komunitas ?>">
                      <div class="form-body">
                        <div class="row">
                          <div class="col-md-6 mb-2">
                            <div class="row">
                              <div class="col-md-6">
                                <fieldset class="form-group">
                                  <p>No KTP</p>
                                  <input type="text" class="form-control text-capitalize" id="nik" name="nik"
                                    value="<?php echo $data->nik ?>" readonly>
                                </fieldset>
                              </div>
                              <div class="col-md-6">
                                <fieldset class="form-group">
                                  <p>Nama Penanggung Jawab</p>
                                  <input type="text" id="nama" name="nama" value="<?php echo $data->nama ?>"
                                    class="form-control text-capitalize" aria-describedby="basic-addon4" readonly>
                                </fieldset>
                              </div>
                            </div>

                            <fieldset class="form-group">
                              <p>Nama Komunitas</p>
                              <select type="text" class="form-control selectpicker" style="width: 100%"
                                id="id_komunitas" name="id_komunitas">
                                <option value="" selected disabled>Pilih nama komunitas...</option>
                                <?php foreach($komunitas as $row) { ?>
                                <option class="text-capitalize" value="<?php echo $row->id_komunitas ?>"
                                  <?php if ($data->id_komunitas == $row->id_komunitas){echo "selected";} ?>>
                                  <?php echo $row->nama_komunitas ?>
                                </option>
                                <?php } ?>
                              </select>
                            </fieldset>

                            <fieldset class="form-group">
                              <p>Rekomender</p>
                              <select type="text" class="form-control selectpicker" style="width: 100%"
                                name="info_bantuan">
                                <option value="" selected disabled>Pilih nama rekomender...</option>
                                <?php foreach($rekomender as $row) { ?>
                                <option class="text-capitalize" value="<?php echo $row->id_rekomender ?>"
                                  <?php if ($data->info_bantuan == $row->id_rekomender){echo "selected";} ?>>
                                  <?php echo $row->jenis_rekomender.' - '.$row->nama_rekomender ?>
                                </option>
                                <?php } ?>
                              </select>
                            </fieldset>
                            <fieldset class="form-group">
                              <p>Periode Penerima Manfaat</p>
                              <input type="date" class="form-control text-capitalize" id="periode_bantuan"
                                name="periode_bantuan" value="<?php echo $data->periode_bantuan ?>">
                            </fieldset>
                            <div class="row">
                              <div class="col-md-6">
                                <fieldset class="form-group">
                                  <p>Jenis Bantuan</p>
                                  <input type="text" class="form-control text-capitalize" id="jenis_bantuan"
                                    name="jenis_bantuan" value="<?php echo $data->jenis_bantuan ?>">
                                </fieldset>
                              </div>
                              <div class="col-md-6">
                                <fieldset class="form-group">
                                  <p>Sumber Dana</p>
                                  <input type="text" class="form-control text-capitalize" id="det_sumber_dana"
                                    name="det_sumber_dana" value="<?php echo $data->sumber_dana ?>">
                                </fieldset>
                              </div>
                            </div>

                            <!-- <fieldset class="form-group">
                                <p>Bentuk Manfaat</p>
                                <input type="text" class="form-control text-capitalize" id="bentuk_manfaat" name="bentuk_manfaat" value="<?php echo $data->bentuk_manfaat ?>">
                              </fieldset> 

                              <fieldset class="form-group">
                                <p>Jenis Bantuan</p>
                                <input type="text" class="form-control text-capitalize" id="jenis_bantuan" name="jenis_bantuan" value="<?php echo $data->jenis_bantuan ?>">
                              </fieldset>  

                              <fieldset class="form-group" hidden>
                                <p>Sifat Bantuan</p>
                                <input type="text" class="form-control"  name="sifat_bantuan" value="<?php echo $data->sifat_bantuan ?>" readonly>
                              </fieldset>   -->



                          </div>

                          <div class="col-md-6">
                            <fieldset class="form-group">
                              <p>Jumlah Bantuan</p>
                              <div class="input-group">
                                <div class="input-group-prepend">
                                  <span id="basic-addon1" class="input-group-text">Rp</span>
                                </div>
                                <input type="text" oninput="formatValue('jumlah_permohonan')" id="jumlah_permohonan"
                                  name="jumlah_permohonan" value="<?php echo number_format($data->jumlah_permohonan) ?>"
                                  aria-describedby="basic-addon1" class="form-control">
                              </div>
                            </fieldset>
                            <fieldset class="form-group">
                              <p>Jumlah Penerima Manfaat</p>
                              <div class="input-group">
                                <input type="number" id="jumlah_pm" name="jumlah_pm" class="form-control"
                                  aria-describedby="basic-addon3" value="<?php echo number_format($data->jumlah_pm) ?>">
                                <div class="input-group-append">
                                  <span class="input-group-text" id="basic-addon3">Orang</span>
                                </div>
                              </div>
                            </fieldset>

                            <fieldset class="form-group" style="margin-top: -15.8px;">
                              <p>Asnaf</p>
                              <select class="form-control selectpicker" name="asnaf" required>
                                <option value="" selected disabled>Pilih asnaf...</option>
                                <option value="Mualaf" <?php if ($data->asnaf == 'Mualaf'){echo "selected";}?>>Mualaf
                                </option>
                                <option value="Ghorimin" <?php if ($data->asnaf == 'Ghorimin'){echo "selected";}?>>
                                  Ghorimin</option>
                                <option value="Fisabilillah"
                                  <?php if ($data->asnaf == 'Fisabilillah'){echo "selected";}?>>Fisabilillah</option>
                                <option value="Ibnu Sabil" <?php if ($data->asnaf == 'Ibnu Sabil'){echo "selected";}?>>
                                  Ibnu Sabil</option>
                                <option value="Fakir Miskin"
                                  <?php if ($data->asnaf == 'Fakir Miskin'){echo "selected";}?>>Fakir Miskin</option>
                              </select>
                            </fieldset>

                            <fieldset class="form-group" hidden>
                              <p>Nama Program</p>
                              <input type="hidden" class="form-control text-capitalize" id="id_program"
                                name="id_program" value="<?php echo $data->id_program ?>">
                            </fieldset>

                            <fieldset class="form-group">
                              <p>Sub Program</p>
                              <select class="form-control selectpicker" name="id_subprogram">
                                <option selected disabled>Pilih sub program...</option>
                                <?php foreach($subprogram as $row) { ?>
                                <option value="<?php echo $row->id_subprogram ?>"
                                  <?php if ($data->id_subprogram == $data->id_subprogram){echo "selected";}?>>
                                  <?php echo $row->nama_subprogram ?>
                                </option>
                                <?php } ?>
                              </select>
                            </fieldset>
                            <fieldset class="form-group">
                                  <p>Total Periode</p>
                                  <input type="text" class="form-control text-capitalize" id="total_periode"
                                    name="total_periode" value="<?php echo $data->total_periode ?>" readonly>
                                </fieldset>

                          </div>
                        </div>
                        <?php echo $btn_submit ?> <?php echo $btn_back ?>
                      </div>
                      <?php echo form_close() ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>
<?php $this->load->view('back/template/footer'); ?>

<script type="text/javascript">
  $('.rekomendasi_bantuan').on('change', function () {
    if (this.value == 'Dibantu') {
      $('.ditolak').attr('hidden', false);
      $('.Dibantu').attr('hidden', false);
      $('.Disurvey').attr('hidden', true);
      $('.DatangKembali').attr('hidden', true);
      $('.LengkapiBerkas').attr('hidden', true);
      $('.rencana_bantuan').attr('disabled', false);
      $('.mekanisme_bantuan').attr('disabled', false);
    } else if (this.value == 'Disurvey') {
      $('.ditolak').attr('hidden', false);
      $('.Dibantu').attr('hidden', true);
      $('.Disurvey').attr('hidden', false);
      $('.DatangKembali').attr('hidden', true);
      $('.LengkapiBerkas').attr('hidden', true);
      $('.rencana_bantuan').attr('disabled', false);
      $('.mekanisme_bantuan').attr('disabled', false);
    } else if (this.value == 'Datang Kembali') {
      $('.ditolak').attr('hidden', false);
      $('.Dibantu').attr('hidden', true);
      $('.Disurvey').attr('hidden', true);
      $('.DatangKembali').attr('hidden', false);
      $('.LengkapiBerkas').attr('hidden', true);
      $('.rencana_bantuan').attr('disabled', false);
      $('.mekanisme_bantuan').attr('disabled', false);
    } else if (this.value == 'Lengkapi Berkas') {
      $('.ditolak').attr('hidden', false);
      $('.Dibantu').attr('hidden', true);
      $('.Disurvey').attr('hidden', true);
      $('.DatangKembali').attr('hidden', true);
      $('.LengkapiBerkas').attr('hidden', false);
      $('.rencana_bantuan').attr('disabled', false);
      $('.mekanisme_bantuan').attr('disabled', false);
    } else if (this.value == 'Ditolak') {
      $('.ditolak').attr('hidden', true);
      $('.Dibantu').attr('hidden', false);
      $('.Disurvey').attr('hidden', true);
      $('.DatangKembali').attr('hidden', true);
      $('.LengkapiBerkas').attr('hidden', true);
      $('.rencana_bantuan').attr('disabled', true);
      $('.mekanisme_bantuan').attr('disabled', true);
    }
  })
  $(document).on('click', '#tambahitem', function (e) {
    var Nama = $('#det_nama').val();
    var usia = $('#usia').val();
    var jeniskelamin = $('#jenis_kelamin').val();
    var jenispenyakit = $('#jenis_penyakit').val();
    var ruangperawatan = $('#ruang_perawatan').val();
    var kelaskamar = $('#kls_kamar').val();
    var alamat = $('#alamat').val();
    var kelurahan = $('#kelurahan').val();
    var kecamatan = $('#kecamatan').val();
    var kota = $('#kota').val();
    var kesan = $('#kesan').val();

    console.log(Nama);
    // var status_pengeriman = $('#id').val();

    tempRow = "<tr id='tr-" + Nama + "'>";
    // tempRow += "<input type='hidden' value='"+id+"' name='item_id[]'/>";
    // tempRow += "<input type='hidden' value='"+pengiriman+"' name='pengiriman[]'/>";
    tempRow += "<input type='hidden' value='" + Nama + "' name='unama[]'/>";
    tempRow += "<input type='hidden' value='" + usia + "' name='uusia[]'/>";
    tempRow += "<input type='hidden' value='" + jeniskelamin + "' name='ujeniskelamin[]'/>";
    tempRow += "<input type='hidden' value='" + jenispenyakit + "' name='ujenispenyakit[]'/>";
    tempRow += "<input type='hidden' value='" + ruangperawatan + "' name='uruangperawatan[]'/>";
    tempRow += "<input type='hidden' value='" + alamat + "' name='ualamat[]'/>";
    tempRow += "<input type='hidden' value='" + kelurahan + "' name='ukelurahan[]'/>";
    tempRow += "<input type='hidden' value='" + kelaskamar + "' name='ukelaskamar[]'/>";
    tempRow += "<input type='hidden' value='" + kecamatan + "' name='ukecamatan[]'/>";
    tempRow += "<input type='hidden' value='" + kota + "' name='ukota[]'/>";
    tempRow += "<input type='hidden' value='" + kesan + "' name='ukesan[]'/>";


    tempRow += "<td>" + Nama + "</td><td>" + usia + "</td><td>" + jeniskelamin + "</td><td>" + jenispenyakit +
      "</td>";
    // tempRow += "<td>"+Komoditas+"</td><td>"+Nama+"</td><td>"+berat+"</td><td>"+Price_brt+"</td>";
    // tempRow += "<td>"+row.stock_awal+"</td><td>"+row.penggunaan+"</td><td>"+row.stock_akhir+"</td><td><input class='form-control input-sm qty-text' type='number' name='req[]' value='0'/></td>";
    tempRow += "<td><a class='delete-data' id='" + Nama +
      "'><i class='ft ft-delete' data-toggle='tooltip' title='Hapus'></i></a></td></tr>";
    // alert(po_tujuan);



    // var qty = $("#txtQTY").val(); //check qty=
    $("#tabelisian tbody").append(tempRow).show('slow', function () {
      //  $('.qty-text:last').val(qty); //override qty
    });
    //reset input text and tempRow
    $('#det_nama').val('');
    $('#usia').val('');
    $('#jenis_kelamin').val('');
    $('#jenis_penyakit').val('');
    $('#ruang_perawatan').val('');
    $('#kls_kamar').val('');
    $('#alamat').val('');
    $('#kelurahan').val('');
    $('#kecamatan').val('');
    $('#kota').val('');
    $('#kesan').val('');



    tempRow = '';
  })
  //delete row
  $(document).on('click', '.delete-data', function (e) {
    var id = $(this).attr('id');
    $('#tr-' + id).remove();
  })
</script>